function o() {
   document. getElementById("side").style.display = "block"
}function c() {
   document. getElementById("side").style.display = "none"
}
